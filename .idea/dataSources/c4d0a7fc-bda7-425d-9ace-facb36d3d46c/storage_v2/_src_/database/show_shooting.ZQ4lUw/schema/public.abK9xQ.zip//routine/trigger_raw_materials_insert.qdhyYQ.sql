create function trigger_raw_materials_insert() returns trigger
    language plpgsql
as
$$
begin
    if ((new.duration = 0) && (new.status = 'Not started')) then
        select new.duration into new.duration;
        select new.status into new.status;
    else
        raise exception 'Неправильные входные данные';
    end if;
    return new;
end;
$$;

alter function trigger_raw_materials_insert() owner to postgres;

