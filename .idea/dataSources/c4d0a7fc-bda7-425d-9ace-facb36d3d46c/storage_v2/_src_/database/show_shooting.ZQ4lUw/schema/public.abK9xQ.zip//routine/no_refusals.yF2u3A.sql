create function no_refusals(deny1 boolean, deny2 boolean) returns boolean
    language plpgsql
as
$$
declare
        result text;
    begin
        if (deny1 = true) || (deny2 = true) then
            result := false;
        else
            result := true;
        end if;

        return result;
    end;
$$;

alter function no_refusals(boolean, boolean) owner to postgres;

