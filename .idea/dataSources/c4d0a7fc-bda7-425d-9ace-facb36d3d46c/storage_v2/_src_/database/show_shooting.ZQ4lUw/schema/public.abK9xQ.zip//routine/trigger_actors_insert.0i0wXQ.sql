create function trigger_actors_insert() returns trigger
    language plpgsql
as
$$
begin
        if (new.age > 9) then
            select new.age into new.age;
        else
            raise exception 'Неправильные входные данные';
        end if;
        return new;
    end
$$;

alter function trigger_actors_insert() owner to postgres;

